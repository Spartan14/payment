package WalletUI;
import java.util.Scanner;

import Walletdao.UserException;
public class WalletUI {
	public static void main(String args[]) throws UserException {
		int i;
		char choice;
		WalletMod WalletMods = new WalletMod();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("\n Welcome to our online Wallet Portal\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Exit\n");
			System.out.print("Enter your choice : ");
			i= sc.nextInt();
			switch(i) {
			case 1:
				try
				{
				WalletMods.createAccount();
				}
				catch(Exception e)
				{
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case 2:
				try
				{
				float bal=WalletMods.showBalance();
				System.out.println("Your Account Balance is: " +bal);			//Printing the account balance
				}
				catch(Exception e)
				{
					System.out.println("try again");
				}
				break;
			case 3:
				try
				{
				float bal=(float) WalletMods.deposit();
				System.out.println("Your account balance is: " + bal);
				}
				catch(Exception e)
				{
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case 4:
				try
				{
				float bal=WalletMods.withdraw();
				System.out.println("Withdraw successful.");
				System.out.println("Your account balance is: " +bal);
				}
				catch(Exception e)
				{
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case 5:
				String s;
				try
				{
				s=WalletMods.fundTransfer();
				if(s!=null)
				{
					System.out.println("Funds Transferred Successfully.");
				System.out.println(s);
				}
				}
				catch(Exception e)
				{
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case 6:
				System.out.println("Thank You ! for using ");
				System.exit(0);
			default:
				System.out.println("Invalid Input Try Again !!!!!!!!");
			}
			System.out.print("Do you want to continue (y/n)...? : ");
			choice = sc.next().charAt(0);
			if(choice == 'y' || choice=='Y')
				continue;
			else if(choice=='n'||choice=='N'){
				System.out.println("Thank You !");
				System.exit(0);
			}
			else
			{
				System.out.println("Invalid Input");
			}
		} while(i != 6 );
		sc.close();
	}
}