package WalletService;

import WalletBean.WalletBean;
import Walletdao.UserException;
import Walletdao.WalletDao;

public class WalletService implements WalletServiceInt{
WalletDao daoObj = new WalletDao();
	
	public void bankAccountCreate(WalletBean bankBeanObjCreateAccountObj)
	{
		daoObj.addCustomer(bankBeanObjCreateAccountObj);
	}
	
	public float showBalanceSer(WalletBean bankBeanShowBalObj)throws UserException 
	{
		float bal=0;
		if(daoObj.hm().isEmpty()) 
		{									// CHECKING IF HASH MAP IS EMPTY OR NOT
			throw new UserException("Please create an account first.");
		}
		else 
		{
			if(daoObj.hm().containsKey(bankBeanShowBalObj.getAccNo())) 
			{
				bal=daoObj.hm().get(bankBeanShowBalObj.getAccNo()).getBalance();
			}
			else 
			{
				throw new UserException("No such Account Exist.");
			}
		}
		return bal;
	}
	
	public float depositSer(WalletBean bankBeanDepObj)throws UserException{
		float bal;
		if(daoObj.hm().isEmpty()) 
		{
			throw new UserException("Create Account First");
		}
		else 
		{
			if(daoObj.hm().containsKey(bankBeanDepObj.getAccNo())) {
				daoObj.deposit(bankBeanDepObj);
				bal=daoObj.hm().get(bankBeanDepObj.getAccNo()).getBalance();					// PRINTING THE BANK BALANCE
		}
			else 
			{
				throw new UserException("No such Account exist");
			}
		}
		return bal;
	}
	
	public float withdrawSer(WalletBean bankBeanWithdrawObj) throws UserException {
		float bal=0;
		if(daoObj.hm().isEmpty()) 
		{
			throw new UserException("Please create an account first.");
		}
		else 
		{		
			if(!daoObj.hm().containsKey(bankBeanWithdrawObj.getAccNo())) 
				{		
					throw new UserException("No such Account Exist.");
					
				}
				else 
				{
					if(bankBeanWithdrawObj.getWithdrawAmount() < daoObj.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance())
						{
							daoObj.withDraw(bankBeanWithdrawObj);	
							bal=daoObj.hm().get(bankBeanWithdrawObj.getAccNo()).getBalance();				// PRINTING REMAINING BALANCE
						}
					else 
						{
	
							throw new UserException("Can't withdraw money. Account Balance is low.");
						}
				}
		}
	return bal;
	}
	
	public String transferSer(WalletBean bankBeanFundTransObj)  throws UserException {
		String s=null;
		if(daoObj.hm().isEmpty()) 
		{
			throw new UserException("Please create an account first.");
		}
		else 
		{
			if(daoObj.hm().containsKey(bankBeanFundTransObj.getSourceAccNo())) 
			{					// CHECKING IF SOURCE ACCOUNT EXIST
				if(daoObj.hm().containsKey(bankBeanFundTransObj.getDestAccNo()))
				{
					if(bankBeanFundTransObj.getSourceAccNo()!=bankBeanFundTransObj.getDestAccNo())
					{
					// CHECKING IF DESTINATION ACCOUNT EXIST
						if(daoObj.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() > bankBeanFundTransObj.getTransferAmount()) 
							{		// CHECKING IF TRANSFER AMOUNT IS GREATER THAN BALANCE OR NOT
								daoObj.transfer( bankBeanFundTransObj);
								s="Remaining balance in account number "+bankBeanFundTransObj.getSourceAccNo()+" is: " +daoObj.hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance();
							}
						else 
							{
								throw new UserException("Can't transfer money. Source Account Balance is low.");
							}
					}
					else
						{
							throw new UserException("transfer from same account to same account is invalid");
						}
				}
				else
					{
						throw new UserException("Destination Account Not Exist.");
					}
			}
			else 
				{
					throw new UserException("Source Account Not Exist.");
				}
		}
		return s;
	}
}

