package Walletdao;

import java.util.HashMap;

import WalletBean.WalletBean;

public class WalletDao {
	//WalletBean beanObj;
	
	HashMap<Long, WalletBean> hm = new HashMap<Long, WalletBean>();
	
	public void addCustomer(WalletBean WalletBeans) {			// Method To Add Customer 
		//this.beanObj = WalletBeans;						// Storing object 
		hm.put(WalletBeans.getAccNo(), WalletBeans);			// Store  in Hash Map 
	}
	public HashMap<Long,WalletBean> hm(){						//  Return Hash Map Object
		return hm;
	}
	public void withDraw(WalletBean bankBeanWithdrawObj) 	//update withdraw amount
	{
		float dep =hm().get(bankBeanWithdrawObj.getAccNo()).getBalance() - bankBeanWithdrawObj.getWithdrawAmount();			// DECREMENTING WITHDRAW AMOUNT FROM BANK ACCOUNT
		hm().get(bankBeanWithdrawObj.getAccNo()).setBalance(dep);
	}
	public void transfer(WalletBean  bankBeanFundTransObj)	//update both source and destination account balance
	{
		float transfer = bankBeanFundTransObj.getTransferAmount();
		hm().get(bankBeanFundTransObj.getSourceAccNo()).setBalance(hm().get(bankBeanFundTransObj.getSourceAccNo()).getBalance() - transfer);		// DECREMENTING THE TRANSFER AMOUNT
		hm().get(bankBeanFundTransObj.getDestAccNo()).setBalance(hm().get(bankBeanFundTransObj.getDestAccNo()).getBalance() + transfer);			// ADDING THE TRANSFER AMOUNT
	}
	public void deposit(WalletBean bankBeanDepObj) //update deposit amount 
	{
		float dep = bankBeanDepObj.getDepAmount() + hm().get(bankBeanDepObj.getAccNo()).getBalance();						// ADDING DEPOSIT AMOUNT TO BANK ACCOUNT
		hm().get(bankBeanDepObj.getAccNo()).setBalance(dep);
		
		
	}
}
